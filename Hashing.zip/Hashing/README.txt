Hashes are used to encrypt user passwords. They are designed to be impossible to computationally reverse. However some hashes have vulnerabilities, if you are unable to exploit these vulnerabilities then just find someone else’s software that can. 

PS: Large online databases with hashes and the original phrase can also be consulted for really common hashes 
